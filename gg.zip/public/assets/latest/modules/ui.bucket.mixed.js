(function(G, w, d){
  'use strict';
  if (!G) return;
  G.modules = G.modules || {};
  var mixed = G.modules.mixedMedia = G.modules.mixedMedia || {};
  if (mixed.__v2Defined) return;
  mixed.__v2Defined = true;

  var DEFAULT_FETCH_MAX = 84;
  var DEFAULT_ORDER = 'published';
  var globalPayload = null;
  var globalFetchPromise = null;
  var labelFetchPromises = Object.create(null);
  var mixedThumbLeadUsed = false;

  function esc(v) {
    return String(v || '').replace(/[&<>"']/g, function(ch){
      return ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[ch];
    });
  }

  function clampInt(v, fallback, min, max) {
    var n = parseInt(v, 10);
    if (!isFinite(n)) n = fallback;
    if (isFinite(min)) n = Math.max(min, n);
    if (isFinite(max)) n = Math.min(max, n);
    return n;
  }

  function normalizeLabel(v) {
    return String(v || '').trim().toLowerCase();
  }

  function toLabelList(raw) {
    var out = [];
    var i;
    if (Array.isArray(raw)) {
      for (i = 0; i < raw.length; i++) {
        var item = String(raw[i] || '').trim();
        if (item) out.push(item);
      }
    } else {
      var str = String(raw || '').trim();
      if (str) {
        out = str.split(',').map(function(part){ return String(part || '').trim(); }).filter(Boolean);
      }
    }
    var seen = Object.create(null);
    var deduped = [];
    for (i = 0; i < out.length; i++) {
      var key = normalizeLabel(out[i]);
      if (!key || seen[key]) continue;
      seen[key] = 1;
      deduped.push(out[i]);
    }
    return deduped;
  }

  function inferType(raw, kindRaw) {
    var v = normalizeLabel(raw);
    var kind = normalizeLabel(kindRaw);
    if (v === 'rail') {
      if (kind === 'youtubeish' || kind === 'youtube') return 'youtube';
      if (kind === 'shortish' || kind === 'shorts' || kind === 'short') return 'shorts';
      if (kind === 'podcastish' || kind === 'podcast') return 'podcast';
      if (kind === 'popular') return 'popular';
      return 'rail';
    }
    if (v === 'featured' || v === 'featuredish') return 'rail';
    if (v === 'youtubeish' || v === 'youtube') return 'youtube';
    if (v === 'shortish' || v === 'shorts' || v === 'short') return 'shorts';
    if (v === 'podcastish' || v === 'podcast') return 'podcast';
    if (v === 'instagramish' || v === 'instagram') return 'instagram';
    if (v === 'newsish' || v === 'newsdeck' || v === 'news') return 'newsdeck';
    if (v === 'popular') return 'popular';
    if (v === 'bookish') return 'bookish';
    if (v === 'pinterestish' || v === 'pinterest') return 'instagram';
    return v || 'bookish';
  }

  function isRailType(type) {
    return type === 'rail' || type === 'youtube' || type === 'shorts' || type === 'podcast' || type === 'popular';
  }

  function titleCaseLabel(label) {
    var clean = String(label || '').trim();
    if (!clean) return 'Mixed';
    return clean
      .split(/[\s_-]+/)
      .filter(Boolean)
      .map(function(p){ return p.charAt(0).toUpperCase() + p.slice(1).toLowerCase(); })
      .join(' ');
  }

  function headingKey(v) {
    return String(v || '')
      .toLowerCase()
      .replace(/&amp;/g, '&')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  function getFeedBase() {
    var cfg = (G.store && G.store.config) ? G.store.config : {};
    var base = String(cfg.feedSummaryBase || '/feeds/posts/summary');
    if (base.charAt(0) !== '/') base = '/' + base;
    return base.replace(/\/$/, '');
  }

  function buildFeedUrl(opts) {
    var o = opts || {};
    var label = String(o.label || '').trim();
    var max = clampInt(o.max, 8, 1, 120);
    var order = String(o.order || DEFAULT_ORDER).trim() || DEFAULT_ORDER;
    var path = getFeedBase();
    var lowLabel = normalizeLabel(label);
    if (label && lowLabel !== 'blog') {
      path += '/-/' + encodeURIComponent(label);
    }
    return (
      path +
      '?alt=json' +
      '&orderby=' + encodeURIComponent(order) +
      '&max-results=' + encodeURIComponent(max)
    );
  }

  function fetchJson(url) {
    if (G.services && G.services.api && typeof G.services.api.fetch === 'function') {
      return G.services.api.fetch(url, 'json');
    }
    return w.fetch(url, { credentials: 'same-origin' }).then(function(res){
      if (!res || !res.ok) throw new Error('feed-unavailable');
      return res.json();
    });
  }

  function pickAltUrl(entry) {
    var links = (entry && entry.link) ? entry.link : [];
    for (var i = 0; i < links.length; i++) {
      if (links[i] && links[i].rel === 'alternate' && links[i].href) {
        return String(links[i].href);
      }
    }
    return '';
  }

  function extractImage(entry) {
    var thumb = entry && (entry['media$thumbnail'] || entry.media$thumbnail);
    if (thumb && thumb.url) return String(thumb.url);
    var html = '';
    if (entry && entry.content && entry.content.$t) html = entry.content.$t;
    if (!html && entry && entry.summary && entry.summary.$t) html = entry.summary.$t;
    var m = String(html || '').match(/<img[^>]+src=["']([^"']+)["']/i);
    return (m && m[1]) ? String(m[1]) : '';
  }

  function normalizeEntry(entry) {
    var title = (entry && entry.title && entry.title.$t) ? String(entry.title.$t).trim() : '';
    var url = pickAltUrl(entry);
    if (!title || !url) return null;

    var cats = (entry && entry.category) ? entry.category : [];
    var labels = [];
    for (var i = 0; i < cats.length; i++) {
      var term = cats[i] && cats[i].term ? String(cats[i].term).trim() : '';
      if (term) labels.push(term);
    }

    return {
      title: title,
      url: url,
      image: extractImage(entry),
      labels: labels,
      published: (entry && entry.published && entry.published.$t) ? String(entry.published.$t) : ''
    };
  }

  function toEntries(json) {
    var feed = json && json.feed ? json.feed : {};
    var raw = Array.isArray(feed.entry) ? feed.entry : [];
    var out = [];
    for (var i = 0; i < raw.length; i++) {
      var item = normalizeEntry(raw[i]);
      if (item) out.push(item);
    }
    return out;
  }

  function dedupe(entries) {
    var seen = Object.create(null);
    var out = [];
    for (var i = 0; i < entries.length; i++) {
      var e = entries[i];
      var key = e && e.url ? String(e.url) : '';
      if (!key || seen[key]) continue;
      seen[key] = 1;
      out.push(e);
    }
    return out;
  }

  function groupByLabel(entries) {
    var groups = Object.create(null);
    for (var i = 0; i < entries.length; i++) {
      var item = entries[i];
      var labels = Array.isArray(item.labels) ? item.labels : [];
      if (!labels.length) {
        if (!groups.blog) groups.blog = [];
        groups.blog.push(item);
        continue;
      }
      for (var j = 0; j < labels.length; j++) {
        var key = normalizeLabel(labels[j]);
        if (!key) continue;
        if (!groups[key]) groups[key] = [];
        groups[key].push(item);
      }
    }
    return groups;
  }

  function parseConfig() {
    var cfg = {
      fetch: {
        max_results: DEFAULT_FETCH_MAX,
        order: DEFAULT_ORDER,
      },
      sectionsById: Object.create(null),
    };

    var el = d.getElementById('gg-mixed-config');
    if (!el) return cfg;

    try {
      var raw = JSON.parse(el.textContent || '{}');
      if (raw && raw.fetch && typeof raw.fetch === 'object') {
        cfg.fetch.max_results = clampInt(raw.fetch.max_results, DEFAULT_FETCH_MAX, 1, 120);
        cfg.fetch.order = String(raw.fetch.order || DEFAULT_ORDER).trim() || DEFAULT_ORDER;
      }
      var sections = Array.isArray(raw && raw.sections) ? raw.sections : [];
      for (var i = 0; i < sections.length; i++) {
        var s = sections[i] || {};
        var id = String(s.id || '').trim();
        if (!id) continue;
        cfg.sectionsById[id] = {
          id: id,
          type: inferType(s.type, s.kind || s.type),
          kind: normalizeLabel(s.kind || s.type || ''),
          label: String(s.label || '').trim(),
          labels: toLabelList(s.labels || ''),
          cols: clampInt(s.cols, 3, 1, 3),
          max: clampInt(s.max, 8, 1, 16),
          order: String(s.order || cfg.fetch.order || DEFAULT_ORDER).trim() || DEFAULT_ORDER,
          defer: s.defer === true || String(s.defer || '') === '1',
          kicker: String(s.kicker || '').trim(),
          title: String(s.title || '').trim(),
        };
      }
    } catch (_) {
      return cfg;
    }

    return cfg;
  }

  function resolveSectionConfig(slot, cfg) {
    var id = String(slot.id || '').trim();
    var fromJson = (id && cfg.sectionsById[id]) ? cfg.sectionsById[id] : null;

    var kindRaw = slot.getAttribute('data-gg-kind') || (fromJson && (fromJson.kind || fromJson.type)) || slot.getAttribute('data-type') || 'bookish';
    var typeRaw = (fromJson && fromJson.type) || slot.getAttribute('data-type') || kindRaw || 'bookish';
    var type = inferType(typeRaw, kindRaw);
    var label = (fromJson && fromJson.label) || slot.getAttribute('data-label') || slot.getAttribute('data-gg-label') || 'blog';
    var labels = toLabelList((fromJson && fromJson.labels) || slot.getAttribute('data-labels') || slot.getAttribute('data-gg-labels') || '');
    var colsRaw = (fromJson && fromJson.cols) || slot.getAttribute('data-cols') || slot.getAttribute('data-gg-cols') || '3';
    var maxRaw = (fromJson && fromJson.max) || slot.getAttribute('data-max') || slot.getAttribute('data-gg-max') || '8';
    var order = (fromJson && fromJson.order) || slot.getAttribute('data-order') || cfg.fetch.order || DEFAULT_ORDER;
    var deferRaw =
      (fromJson && (fromJson.defer === true || String(fromJson.defer || '') === '1')) ||
      slot.getAttribute('data-gg-defer') === '1' ||
      slot.getAttribute('data-defer') === '1';

    var section = {
      id: id,
      type: type,
      kind: normalizeLabel(kindRaw || type),
      label: String(label || '').trim(),
      labels: labels,
      cols: clampInt(colsRaw, 3, 1, 3),
      max: clampInt(maxRaw, 8, 1, 16),
      order: String(order || DEFAULT_ORDER).trim() || DEFAULT_ORDER,
      defer: !!deferRaw,
      kicker: (fromJson && fromJson.kicker) ? String(fromJson.kicker).trim() : '',
      title: (fromJson && fromJson.title) ? String(fromJson.title).trim() : '',
    };

    if (section.type === 'newsdeck') {
      if (!section.labels.length) {
        section.labels = toLabelList(section.label);
      }
      if (!section.labels.length) {
        section.labels = ['news'];
      }
      section.label = section.labels[0];
      section.maxTotal = section.max * section.cols;
    } else {
      section.cols = 1;
      section.maxTotal = section.max;
    }

    if (!section.kicker) {
      section.kicker = titleCaseLabel(section.label || section.type).toUpperCase();
    }
    return section;
  }

  function buildSeeAllUrl(label) {
    var clean = String(label || '').trim();
    if (!clean) return '/blog';
    return '/search/label/' + encodeURIComponent(clean);
  }

  function applySectionUi(slot, section) {
    slot.setAttribute('data-type', section.type);
    slot.setAttribute('data-label', section.label);
    if (section.labels && section.labels.length) {
      slot.setAttribute('data-gg-labels', section.labels.join(','));
      slot.setAttribute('data-labels', section.labels.join(','));
    }
    slot.setAttribute('data-gg-cols', String(section.cols || 1));
    slot.setAttribute('data-cols', String(section.cols || 1));
    slot.setAttribute('data-gg-max', String(section.max));
    slot.setAttribute('data-max', String(section.max));
    slot.setAttribute('data-gg-max-total', String(section.maxTotal || section.max));
    slot.setAttribute('data-order', section.order);
    if (section.defer) slot.setAttribute('data-gg-defer', '1');
    else slot.removeAttribute('data-gg-defer');

    var kickerText = String(section.kicker || titleCaseLabel(section.label || section.type || 'Mixed').toUpperCase()).trim();
    var kickerEl = slot.querySelector('[data-role="kicker"]');
    if (kickerEl && kickerText) kickerEl.textContent = kickerText;

    var titleEl = slot.querySelector('.gg-mixed__title');
    if (titleEl) {
      var fallbackTitle = String(titleEl.textContent || '').trim();
      var nextTitle = String(section.title || fallbackTitle).trim();
      if (headingKey(nextTitle) && headingKey(nextTitle) === headingKey(kickerText)) {
        nextTitle = '';
      }
      if (nextTitle) {
        titleEl.textContent = nextTitle;
        titleEl.removeAttribute('hidden');
        slot.removeAttribute('data-gg-title-empty');
      } else {
        titleEl.textContent = '';
        titleEl.setAttribute('hidden', 'hidden');
        slot.setAttribute('data-gg-title-empty', '1');
      }
    }

    var moreEl = slot.querySelector('[data-role="more"]') || slot.querySelector('.gg-mixed__more');
    if (moreEl) {
      var moreLabel = section.label;
      if (section.type === 'newsdeck' && section.labels && section.labels.length) {
        moreLabel = section.labels[0];
      }
      moreEl.setAttribute('href', buildSeeAllUrl(moreLabel));
      moreEl.textContent = 'See all';
    }
  }

  function setState(slot, state) {
    if (!slot) return;
    slot.setAttribute('data-gg-state', state);
  }

  function setError(slot, msg) {
    var el = slot.querySelector('[data-role="error"]');
    if (!el) return;
    el.textContent = String(msg || 'Feed unavailable.');
    el.removeAttribute('hidden');
  }

  function clearError(slot) {
    var el = slot.querySelector('[data-role="error"]');
    if (!el) return;
    el.setAttribute('hidden', 'hidden');
  }

  function skeletonCountFor(section) {
    var count = clampInt(section && section.max, 8, 1, 16);
    if (inferType(section && section.type) === 'newsdeck') {
      return count * clampInt(section && section.cols, 3, 1, 3);
    }
    return count;
  }

  function createEl(tag, className) {
    var el = d.createElement(tag);
    if (className) el.className = className;
    return el;
  }

  function clearNode(node) {
    if (!node) return;
    node.textContent = '';
  }

  function createMixedSkeletonCard() {
    var article = createEl('article', 'gg-mixed__card gg-mixed__card--placeholder');
    article.setAttribute('aria-hidden', 'true');

    var thumb = createEl('span', 'gg-mixed__thumb');
    var body = createEl('span', 'gg-mixed__body');
    var kicker = createEl('span', 'gg-mixed__kicker');
    var headline = createEl('span', 'gg-mixed__headline');

    body.appendChild(kicker);
    body.appendChild(headline);
    article.appendChild(thumb);
    article.appendChild(body);
    return article;
  }

  function createNewsDeckSkeletonItem() {
    var article = createEl('article', 'gg-newsdeck__item gg-newsdeck__item--placeholder');
    article.setAttribute('aria-hidden', 'true');

    var body = createEl('span', 'gg-newsdeck__body');
    body.appendChild(createEl('span', 'gg-newsdeck__kicker'));
    body.appendChild(createEl('span', 'gg-newsdeck__title'));
    body.appendChild(createEl('span', 'gg-newsdeck__time'));

    article.appendChild(body);
    article.appendChild(createEl('span', 'gg-newsdeck__thumb'));
    return article;
  }

  function buildNewsDeckSkeleton(section, count) {
    var colCount = clampInt(section && section.cols, 3, 1, 3);
    var rowCount = clampInt(section && section.max, 3, 1, 16);
    var labels = toLabelList(section && section.labels);
    if (!labels.length) labels = [section && section.label ? section.label : 'news'];

    var wrap = createEl('div', 'gg-newsdeck');
    if (colCount < 1) colCount = 1;

    for (var c = 0; c < colCount; c++) {
      var col = createEl('div', 'gg-newsdeck__col');
      var label = createEl('p', 'gg-newsdeck__col-label');
      label.textContent = titleCaseLabel(labels[c] || labels[labels.length - 1] || 'news');
      col.appendChild(label);
      for (var i = 0; i < rowCount; i++) {
        col.appendChild(createNewsDeckSkeletonItem());
      }
      wrap.appendChild(col);
    }

    if (!wrap.childNodes.length) {
      for (var k = 0; k < count; k++) {
        wrap.appendChild(createNewsDeckSkeletonItem());
      }
    }
    return wrap;
  }

  function renderSkeleton(slot, section) {
    if (!slot) return;
    var grid = slot.querySelector('[data-role="grid"]');
    var rail = slot.querySelector('[data-role="rail"]');
    var count = skeletonCountFor(section);

    slot.setAttribute('data-gg-skeleton-count', String(count));
    if (section.type === 'newsdeck') {
      if (grid) {
        clearNode(grid);
        grid.appendChild(buildNewsDeckSkeleton(section, count));
        grid.removeAttribute('hidden');
      }
      if (rail) {
        clearNode(rail);
        rail.setAttribute('hidden', 'hidden');
      }
      return;
    }

    if (isRailType(section.type)) {
      if (rail) {
        clearNode(rail);
        for (var i = 0; i < count; i++) {
          rail.appendChild(createMixedSkeletonCard());
        }
        rail.removeAttribute('hidden');
      }
      if (grid) {
        clearNode(grid);
        grid.setAttribute('hidden', 'hidden');
      }
      return;
    }

    if (grid) {
      clearNode(grid);
      for (var j = 0; j < count; j++) {
        grid.appendChild(createMixedSkeletonCard());
      }
      grid.removeAttribute('hidden');
    }
    if (rail) {
      clearNode(rail);
      rail.setAttribute('hidden', 'hidden');
    }
  }

  function ensureGlobal(cfg) {
    if (globalPayload) return Promise.resolve(globalPayload);
    if (globalFetchPromise) return globalFetchPromise;

    var fetchMax = clampInt(cfg.fetch.max_results, DEFAULT_FETCH_MAX, 1, 120);
    var fetchOrder = cfg.fetch.order || DEFAULT_ORDER;
    var url = buildFeedUrl({ max: fetchMax, order: fetchOrder });

    globalFetchPromise = fetchJson(url)
      .then(function(json){
        var entries = dedupe(toEntries(json));
        globalPayload = {
          entries: entries,
          groups: groupByLabel(entries),
        };
        return globalPayload;
      })
      .catch(function(){
        globalPayload = {
          entries: [],
          groups: Object.create(null),
        };
        return globalPayload;
      });

    return globalFetchPromise;
  }

  function ensureLabelFeed(label, max, order) {
    label = String(label || '').trim();
    if (!label) return Promise.resolve([]);

    var safeMax = clampInt(max, 8, 1, 120);
    var safeOrder = String(order || DEFAULT_ORDER).trim() || DEFAULT_ORDER;
    var key = [normalizeLabel(label), safeMax, safeOrder].join('|');
    if (labelFetchPromises[key]) return labelFetchPromises[key];

    var url = buildFeedUrl({ label: label, max: safeMax, order: safeOrder });
    labelFetchPromises[key] = fetchJson(url)
      .then(function(json){ return dedupe(toEntries(json)); })
      .catch(function(){ return []; });

    return labelFetchPromises[key];
  }

  function pickFromGroup(globalData, label, max) {
    var key = normalizeLabel(label);
    var groups = globalData && globalData.groups ? globalData.groups : {};
    var entries = globalData && Array.isArray(globalData.entries) ? globalData.entries : [];

    var out = [];
    if (key && groups[key]) out = groups[key].slice(0, max);
    if (!out.length && (key === 'blog' || !key)) out = entries.slice(0, max);
    return out;
  }

  function fillToCount(items, fallback, max) {
    var out = Array.isArray(items) ? items.slice(0, max) : [];
    var src = Array.isArray(fallback) ? fallback.slice() : [];
    var i = 0;
    if (!src.length) return out.slice(0, max);
    while (out.length < max && src.length) {
      out.push(src[i % src.length]);
      i += 1;
    }
    return out.slice(0, max);
  }

  function resolveNewsDeckColumns(section, cfg) {
    return ensureGlobal(cfg).then(function(globalData){
      var cols = clampInt(section && section.cols, 3, 1, 3);
      var perCol = clampInt(section && section.max, 3, 1, 16);
      var labels = toLabelList(section && section.labels);
      if (!labels.length) labels = toLabelList(section && section.label);
      if (!labels.length) labels = ['news'];
      while (labels.length < cols) {
        labels.push(labels[labels.length - 1]);
      }

      var tasks = [];
      for (var i = 0; i < cols; i++) {
        (function(colLabel){
          tasks.push(
            (function(){
              return ensureLabelFeed(colLabel, perCol, section.order).then(function(labelEntries){
                var selected = pickFromGroup(globalData, colLabel, perCol);
                var merged = dedupe((labelEntries || []).concat(selected));
                if (merged.length < perCol) {
                  merged = dedupe(merged.concat(globalData.entries || []));
                }
                var fallbackPool = dedupe((labelEntries || []).concat(selected).concat(globalData.entries || []));
                return {
                  label: colLabel,
                  items: fillToCount(merged, fallbackPool, perCol)
                };
              });
            })()
          );
        })(labels[i]);
      }

      return Promise.all(tasks);
    });
  }

  function resolveEntries(section, cfg) {
    if (section.type === 'newsdeck') {
      return resolveNewsDeckColumns(section, cfg);
    }
    return ensureGlobal(cfg).then(function(globalData){
      var max = section.max;
      var selected = pickFromGroup(globalData, section.label, max);

      if (selected.length >= max) {
        return selected.slice(0, max);
      }

      return ensureLabelFeed(section.label, section.max, section.order).then(function(labelEntries){
        var merged = dedupe(selected.concat(labelEntries || []));
        if (merged.length < max) {
          merged = dedupe(merged.concat(globalData.entries || []));
        }
        var fallbackPool = dedupe((labelEntries || []).concat(globalData.entries || []).concat(selected));
        return fillToCount(merged, fallbackPool, max);
      });
    });
  }

  function resolveThumbDims(root, section) {
    var kind = '';
    if (root && root.getAttribute) {
      kind = (root.getAttribute('data-gg-kind') || root.getAttribute('data-type') || '').toLowerCase();
    }
    if (!kind && section) {
      kind = String(section.kind || section.type || '').toLowerCase();
    }
    var dims = [100, 148];
    switch (kind) {
      case 'youtube':
      case 'youtubeish':
        dims = [16, 9];
        break;
      case 'shorts':
      case 'short':
      case 'shortish':
        dims = [9, 16];
        break;
      case 'instagram':
      case 'instagramish':
        dims = [4, 6];
        break;
      case 'podcast':
      case 'podcastish':
      case 'newsdeck':
      case 'newsish':
        dims = [1, 1];
        break;
      default:
        dims = [100, 148];
        break;
    }
    return dims;
  }

  function appendCardThumb(thumb, imageUrl, root, section) {
    var src = String(imageUrl || '').trim();
    if (!src || !thumb) return;
    var img = createEl('img');
    img.setAttribute('alt', '');
    img.setAttribute('decoding', 'async');
    if (!mixedThumbLeadUsed) {
      img.setAttribute('loading', 'eager');
      img.setAttribute('fetchpriority', 'auto');
      mixedThumbLeadUsed = true;
    } else {
      img.setAttribute('loading', 'lazy');
      img.setAttribute('fetchpriority', 'auto');
    }
    img.setAttribute('src', src);
    var imageSvc = G.services && G.services.images;
    var dims = resolveThumbDims(root, section);
    if (imageSvc && typeof imageSvc.setIntrinsicDims === 'function') {
      imageSvc.setIntrinsicDims(img, dims[0], dims[1]);
    }
    if (imageSvc && typeof imageSvc.buildSrcset === 'function') {
      var widths = [240, 360, 480, 720, 960, 1200];
      var built = imageSvc.buildSrcset(img.src, widths, {
        keepCrop: true,
        max: 1600,
        sizes: '(max-width: 600px) 50vw, (max-width: 1024px) 33vw, 25vw'
      });
      if (built && built.srcset) {
        img.src = built.src || img.src;
        img.srcset = built.srcset;
        if (built.sizes) img.sizes = built.sizes;
      }
    }
    thumb.appendChild(img);
  }

  function timeAgo(iso) {
    var ts = Date.parse(String(iso || ''));
    if (!isFinite(ts)) return '';
    var sec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
    if (sec < 60) return 'just now';
    var min = Math.floor(sec / 60);
    if (min < 60) return min + ' min ago';
    var hr = Math.floor(min / 60);
    if (hr < 24) return hr + ' hr ago';
    var day = Math.floor(hr / 24);
    if (day < 30) return day + ' d ago';
    var mo = Math.floor(day / 30);
    if (mo < 12) return mo + ' mo ago';
    var yr = Math.floor(day / 365);
    return yr + ' y ago';
  }

  function createMixedCard(item, section, root) {
    var safeItem = item || {};
    var kicker = titleCaseLabel((safeItem.labels && safeItem.labels[0]) || section.label || section.type);
    var card = createEl('a', 'gg-mixed__card');
    card.setAttribute('href', safeItem.url || '#');

    var thumb = createEl('span', 'gg-mixed__thumb');
    appendCardThumb(thumb, safeItem.image, root, section);
    card.appendChild(thumb);

    var body = createEl('span', 'gg-mixed__body');
    var kickerEl = createEl('span', 'gg-mixed__kicker');
    kickerEl.textContent = kicker;
    body.appendChild(kickerEl);

    var titleEl = createEl('span', 'gg-mixed__headline');
    titleEl.textContent = String(safeItem.title || '');
    body.appendChild(titleEl);

    card.appendChild(body);
    return card;
  }

  function createNewsDeckItem(item, colLabel, labelName, section, root) {
    var safeItem = item || {};
    var sourceName = titleCaseLabel((safeItem.labels && safeItem.labels[0]) || colLabel || labelName || 'News');
    var ago = timeAgo(safeItem.published || '');
    var dateIso = String(safeItem.published || '');

    var link = createEl('a', 'gg-newsdeck__item');
    link.setAttribute('href', safeItem.url || '#');

    var body = createEl('span', 'gg-newsdeck__body');
    var kicker = createEl('span', 'gg-newsdeck__kicker');
    kicker.textContent = sourceName;
    body.appendChild(kicker);

    var title = createEl('span', 'gg-newsdeck__title');
    title.textContent = String(safeItem.title || '');
    body.appendChild(title);

    var time = createEl('time', 'gg-newsdeck__time');
    time.setAttribute('datetime', dateIso);
    time.appendChild(d.createTextNode(String(ago || 'Just published')));
    var openIcon = createEl('span', 'gg-icon gg-newsdeck__open');
    openIcon.setAttribute('aria-hidden', 'true');
    openIcon.textContent = 'open_in_new';
    time.appendChild(openIcon);
    body.appendChild(time);

    var thumb = createEl('span', 'gg-newsdeck__thumb');
    appendCardThumb(thumb, safeItem.image, root, section);

    link.appendChild(body);
    link.appendChild(thumb);
    return link;
  }

  function createNewsDeck(columns, section, root) {
    var wrap = createEl('div', 'gg-newsdeck');
    var cols = Array.isArray(columns) ? columns : [];
    for (var c = 0; c < cols.length; c++) {
      var col = cols[c] || {};
      var labelName = titleCaseLabel(col.label || (section.labels && section.labels[c]) || section.label || 'News');
      var colEl = createEl('div', 'gg-newsdeck__col');
      var label = createEl('p', 'gg-newsdeck__col-label');
      label.textContent = labelName;
      colEl.appendChild(label);

      var items = Array.isArray(col.items) ? col.items : [];
      for (var r = 0; r < items.length; r++) {
        colEl.appendChild(createNewsDeckItem(items[r], col.label, labelName, section, root));
      }
      wrap.appendChild(colEl);
    }
    return wrap;
  }

  function countNewsDeckItems(columns) {
    if (!Array.isArray(columns)) return 0;
    var total = 0;
    for (var i = 0; i < columns.length; i++) {
      var items = columns[i] && Array.isArray(columns[i].items) ? columns[i].items : [];
      total += items.length;
    }
    return total;
  }

  function render(slot, section, items) {
    var grid = slot.querySelector('[data-role="grid"]');
    var rail = slot.querySelector('[data-role="rail"]');
    var list = Array.isArray(items) ? items : [];

    if (section.type === 'newsdeck') {
      slot.setAttribute('data-gg-render-count', String(countNewsDeckItems(list)));
      if (grid) {
        clearNode(grid);
        grid.appendChild(createNewsDeck(list, section, slot));
        grid.removeAttribute('hidden');
      }
      if (rail) {
        clearNode(rail);
        rail.setAttribute('hidden', 'hidden');
      }
      return;
    }

    slot.setAttribute('data-gg-render-count', String(list.length));

    if (isRailType(section.type)) {
      if (rail) {
        clearNode(rail);
        for (var i = 0; i < list.length; i++) {
          rail.appendChild(createMixedCard(list[i], section, slot));
        }
        rail.removeAttribute('hidden');
      }
      if (grid) {
        clearNode(grid);
        grid.setAttribute('hidden', 'hidden');
      }
      return;
    }

    if (grid) {
      clearNode(grid);
      for (var j = 0; j < list.length; j++) {
        grid.appendChild(createMixedCard(list[j], section, slot));
      }
      grid.removeAttribute('hidden');
    }
    if (rail) {
      clearNode(rail);
      rail.setAttribute('hidden', 'hidden');
    }
  }

  function loadSlot(slot, cfg) {
    if (!slot || slot.__ggMixedLoading) return Promise.resolve();
    if (slot.getAttribute('data-gg-loaded') === '1') return Promise.resolve();

    var section = slot.__ggMixedSection || resolveSectionConfig(slot, cfg);
    slot.__ggMixedSection = section;
    applySectionUi(slot, section);
    renderSkeleton(slot, section);

    slot.__ggMixedLoading = true;
    setState(slot, 'loading');
    clearError(slot);

    return resolveEntries(section, cfg)
      .then(function(items){
        var count = section.type === 'newsdeck' ? countNewsDeckItems(items) : (Array.isArray(items) ? items.length : 0);
        if (!count) {
          setState(slot, 'error');
          setError(slot, 'No posts yet.');
          return;
        }
        render(slot, section, items);
        slot.setAttribute('data-gg-loaded', '1');
        setState(slot, 'loaded');
      }, function(){
        setState(slot, 'error');
        setError(slot, 'Feed unavailable.');
      })
      .then(function(){
        slot.__ggMixedLoading = false;
      });
  }

  function collectSlots(root) {
    var base = root && root.querySelectorAll ? root : d;
    var list = Array.prototype.slice.call(base.querySelectorAll('[data-gg-module="mixed-media"]'));
    if (root && root.nodeType === 1 && root.matches && root.matches('[data-gg-module="mixed-media"]')) {
      list.unshift(root);
    }
    return list.filter(function(slot){
      if (!slot || slot.getAttribute('data-gg-disabled') === '1') return false;
      if (slot.closest && slot.closest('[data-gg-disabled="1"]')) return false;
      return true;
    });
  }

  function init(root) {
    if (G.ui && G.ui.layout && typeof G.ui.layout._normalizeListingFlow === 'function') {
      try { G.ui.layout._normalizeListingFlow(); } catch (_) {}
    }
    var cfg = parseConfig();
    var slots = collectSlots(root);
    if (!slots.length) return;

    for (var i = 0; i < slots.length; i++) {
      slots[i].__ggMixedSection = resolveSectionConfig(slots[i], cfg);
      applySectionUi(slots[i], slots[i].__ggMixedSection);
      if (slots[i].getAttribute('data-gg-loaded') !== '1') {
        renderSkeleton(slots[i], slots[i].__ggMixedSection);
      }
    }

    var eagerSlots = [];
    var deferredSlots = [];
    for (var j = 0; j < slots.length; j++) {
      var section = slots[j].__ggMixedSection || resolveSectionConfig(slots[j], cfg);
      if (section.defer) deferredSlots.push(slots[j]);
      else eagerSlots.push(slots[j]);
    }

    for (var k = 0; k < eagerSlots.length; k++) {
      loadSlot(eagerSlots[k], cfg);
    }

    if (!('IntersectionObserver' in w)) {
      for (var z = 0; z < deferredSlots.length; z++) {
        loadSlot(deferredSlots[z], cfg);
      }
      return;
    }

    var io = new IntersectionObserver(function(entries){
      for (var x = 0; x < entries.length; x++) {
        var entry = entries[x];
        if (!entry.isIntersecting) continue;
        io.unobserve(entry.target);
        loadSlot(entry.target, cfg);
      }
    }, { rootMargin: '900px 0px' });

    for (var m = 0; m < deferredSlots.length; m++) {
      if (deferredSlots[m].getAttribute('data-gg-loaded') === '1') continue;
      io.observe(deferredSlots[m]);
    }
  }

  mixed.init = mixed.init || init;

  if (G.boot && typeof G.boot.onReady === 'function') {
    G.boot.onReady(function(){ mixed.init(d); });
  } else if (d.readyState === 'loading') {
    d.addEventListener('DOMContentLoaded', function(){ mixed.init(d); }, { once: true });
  } else {
    mixed.init(d);
  }
})(window.GG = window.GG || {}, window, document);
